package com.mycompany.ud4.UD4_22;

public interface Pesable {

    public double getPeso();

}
